<!-- Fixed navbar -->
    
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo base_url("home");?>">Reserva de Horas</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="<?php echo base_url("consulta/");?>">Consulta de horas</a></li>
            <li><a href="<?php echo base_url("anulacion/");?>">Anulaci&oacute;n de horas</a></li>
            <li><a href="<?php echo base_url("modificardatos/");?>">Modificar datos</a></li>
            <li><a href="<?php echo base_url("registro/");?>">Registro</a></li>
            
          </ul>
        </div><!--/.nav-collapse -->
      </div>

